<?php
// Cek status session supaya tidak error "session already started"
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = "localhost";
$user = "root";
$pass = "";
$db   = "sobatbranding";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// FUNGSI TAMBAHAN: Biar gampang ambil data user yang lagi login di halaman manapun
if (isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $user_query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$uid'");
    $user_data = mysqli_fetch_assoc($user_query);
    
    // Simpan ke variable global biar bisa dipanggil di navbar/profil
    $current_user = $user_data;
}
?>