<?php
// Proteksi Login
if (!isset($_SESSION['user_id'])) {
    echo "<script>window.location='login.php';</script>"; exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Query Statistik dengan proteksi error
$q_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE user_id = '$user_id'");
$total_order = ($q_total) ? mysqli_fetch_assoc($q_total)['total'] : 0;

$q_pending = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE user_id = '$user_id' AND status = 'pending'");
$pending_order = ($q_pending) ? mysqli_fetch_assoc($q_pending)['total'] : 0;
?>

<div class="bg-slate-50/50 min-h-screen py-12 px-6">
    <div class="max-w-7xl mx-auto">
        
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
            <div>
                <h1 class="text-4xl font-black text-[#1a365d] italic tracking-tighter uppercase">Dashboard <span class="text-[#f38d2c]">User</span></h1>
                <p class="text-slate-400 font-bold text-xs uppercase tracking-[3px] mt-2 text-left">Selamat datang kembali, <?= $username ?>!</p>
            </div>
            <a href="index.php?page=marketplace" class="bg-[#1a365d] text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-100 hover:-translate-y-1 transition-all text-center">Eksplor Jasa</a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div class="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm flex items-center gap-6">
                <div class="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-2xl">📦</div>
                <div class="text-left">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Pesanan</p>
                    <p class="text-3xl font-black text-[#1a365d] italic tracking-tighter"><?= $total_order ?></p>
                </div>
            </div>
            <div class="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm flex items-center gap-6">
                <div class="w-16 h-16 bg-orange-50 rounded-2xl flex items-center justify-center text-2xl">⏳</div>
                <div class="text-left">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Menunggu</p>
                    <p class="text-3xl font-black text-[#f38d2c] italic tracking-tighter"><?= $pending_order ?></p>
                </div>
            </div>
            <div class="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm flex items-center gap-6">
                <div class="w-16 h-16 bg-green-50 rounded-2xl flex items-center justify-center text-2xl">✅</div>
                <div class="text-left">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Selesai</p>
                    <p class="text-3xl font-black text-green-600 italic tracking-tighter">0</p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden">
            <div class="p-10 border-b border-slate-50 flex items-center justify-between">
                <h3 class="text-xl font-black text-[#1a365d] italic uppercase tracking-tighter">Riwayat Pesanan</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50/50">
                            <th class="p-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">Layanan</th>
                            <th class="p-8 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Status</th>
                            <th class="p-8 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50">
                        <?php
                        $orders = mysqli_query($conn, "SELECT orders.*, services.title, services.image 
                                                     FROM orders 
                                                     JOIN services ON orders.service_id = services.id 
                                                     WHERE orders.user_id = '$user_id' 
                                                     ORDER BY orders.id DESC");
                        
                        if ($orders && mysqli_num_rows($orders) > 0):
                            while($item = mysqli_fetch_assoc($orders)): 
                        ?>
                        <tr class="hover:bg-slate-50/50 transition-colors">
                            <td class="p-8">
                                <div class="flex items-center gap-4">
                                    <img src="<?= $item['image'] ?>" class="w-12 h-12 rounded-xl object-cover shadow-sm">
                                    <span class="font-bold text-[#1a365d] text-sm"><?= $item['title'] ?></span>
                                </div>
                            </td>
                            <td class="p-8 text-center">
                                <span class="px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest bg-orange-50 text-orange-500 border border-orange-100">
                                    <?= $item['status'] ?>
                                </span>
                            </td>
                            <td class="p-8 text-center">
                                <button class="text-[10px] font-black text-[#1a365d] uppercase tracking-widest hover:underline">Detail</button>
                            </td>
                        </tr>
                        <?php 
                            endwhile;
                        else: 
                        ?>
                        <tr>
                            <td colspan="3" class="p-20 text-center font-bold text-slate-300 italic uppercase tracking-widest text-xs">Belum ada pesanan aktif</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>