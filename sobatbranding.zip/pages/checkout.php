<?php
include 'config/db.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cek login dulu, biar gak asal bayar
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Data dummy buat contoh
$nama_jasa = "Jasa Desain Grafis Profesional – Solusi Branding Bisnis Anda";
$paket = "LITE";
$harga = 500000;
$biaya_escrow = 10000;
$total = $harga + $biaya_escrow;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | SobatBranding</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f8fafc; }
        .card-custom { border-radius: 24px; border: 1px solid #e2e8f0; }
        .input-checkout { 
            border: 1px solid #e2e8f0; 
            border-radius: 12px; 
            background: #f8fafc;
            padding: 12px 16px;
            font-size: 14px;
        }
        .input-checkout:focus { border-color: #1a365d; outline: none; background: white; }
        
        /* Gaya khusus untuk dropzone bukti transfer */
        #dropzone.active { border-color: #22c55e; background-color: #f0fdf4; }
    </style>
</head>
<body class="pb-20">

    <nav class="bg-white border-b border-gray-100 py-4 px-6 mb-10">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-2">
                <img src="uploads/logo.png" class="w-8 h-8">
                <span class="font-black text-[#1a365d]">Sobat<span class="text-orange-500">Branding</span></span>
            </div>
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-gray-200 overflow-hidden">
                    <img src="https://ui-avatars.com/api/?name=<?= $_SESSION['username'] ?>" alt="User">
                </div>
                <span class="text-sm font-bold text-gray-700"><?= $_SESSION['username'] ?></span>
            </div>
        </div>
    </nav>

    <div class="max-w-5xl mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            <div class="bg-white card-custom p-8 shadow-sm">
                <h2 class="text-xl font-black text-[#1a365d] mb-6 uppercase tracking-tight">Ringkasan Pesanan</h2>
                
                <div class="flex gap-4 mb-8">
                    <img src="https://via.placeholder.com/100x100" class="w-20 h-20 rounded-xl object-cover">
                    <div>
                        <h3 class="font-bold text-sm text-[#1a365d] leading-snug mb-1"><?= $nama_jasa ?></h3>
                        <span class="text-[10px] font-black bg-blue-50 text-blue-600 px-2 py-1 rounded">PAKET: <?= $paket ?></span>
                    </div>
                </div>

                <div class="space-y-4 border-t border-dashed border-gray-200 pt-6">
                    <div class="flex justify-between text-sm font-medium text-gray-500">
                        <span>Harga Jasa</span>
                        <span class="text-[#1a365d] font-bold">Rp<?= number_format($harga, 0, ',', '.') ?></span>
                    </div>
                    <div class="flex justify-between text-sm font-medium text-gray-500">
                        <span>Biaya Layanan (Escrow)</span>
                        <span class="text-[#1a365d] font-bold">Rp<?= number_format($biaya_escrow, 0, ',', '.') ?></span>
                    </div>
                    <div class="flex justify-between items-center border-t border-gray-100 pt-4">
                        <span class="text-base font-black text-[#1a365d]">TOTAL BAYAR</span>
                        <span class="text-xl font-black text-orange-500">Rp<?= number_format($total, 0, ',', '.') ?></span>
                    </div>
                </div>

                <div class="mt-8 bg-blue-50 rounded-2xl p-6 border border-blue-100">
                    <p class="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-3">Rekening Tujuan Transfer</p>
                    <div class="flex justify-between items-center mb-2">
                        <span class="text-sm font-bold text-[#1a365d]">Bank Central Asia</span>
                        <span class="text-base font-black text-[#1a365d]">0542225236</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-bold text-[#1a365d]">Atas Nama</span>
                        <span class="text-sm font-black text-[#1a365d]">PT SOBAT BRANDING INDO</span>
                    </div>
                    <div class="mt-4 bg-orange-100 text-orange-700 text-[10px] font-bold p-3 rounded-lg text-center">
                        Mohon transfer tepat Rp<?= number_format($total, 0, ',', '.') ?> untuk verifikasi otomatis.
                    </div>
                </div>
            </div>

            <div class="bg-white card-custom p-8 shadow-sm h-fit">
                <h2 class="text-xl font-black text-[#1a365d] mb-6 uppercase tracking-tight text-center">Konfirmasi Pembayaran</h2>
                
                <form action="proses_bayar.php" method="POST" enctype="multipart/form-data" class="space-y-5">
                    <div>
                        <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Nama Pengirim Sesuai Rekening</label>
                        <input type="text" name="nama_pengirim" placeholder="Contoh: Budi Santoso" class="w-full input-checkout font-bold" required>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Metode Bayar</label>
                            <select name="metode" class="w-full input-checkout font-bold">
                                <option value="BCA">BCA</option>
                                <option value="DANA">DANA</option>
                                <option value="QRIS">QRIS</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Nominal Transfer</label>
                            <input type="number" name="nominal" value="<?= $total ?>" class="w-full input-checkout font-bold text-gray-500" readonly>
                        </div>
                    </div>

                    <div>
                        <label class="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Unggah Bukti Transfer (Max 5MB)</label>
                        <div id="dropzone" class="border-2 border-dashed border-gray-200 rounded-2xl p-8 text-center hover:border-orange-400 transition-all cursor-pointer relative overflow-hidden h-40 flex items-center justify-center">
                            
                            <input type="file" name="bukti" id="bukti" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" required onchange="displayPreview(this)">
                            
                            <div id="placeholder-text" class="text-gray-400 transition-opacity duration-300">
                                <svg class="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"/><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                                <span class="text-[10px] font-black uppercase tracking-widest">Klik atau pilih foto bukti</span>
                            </div>

                            <div id="preview-container" class="hidden absolute inset-0 w-full h-full bg-white">
                                <img id="img-preview" src="#" class="w-full h-full object-cover">
                                <div class="absolute inset-0 bg-black/40 flex flex-col items-center justify-center text-white p-4">
                                    <svg class="w-6 h-6 mb-1 text-green-400 shadow-sm" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                                    <span id="file-name-text" class="text-[10px] font-black uppercase truncate max-w-full">File Terpilih</span>
                                    <span class="text-[8px] opacity-80 uppercase mt-1">Klik untuk ganti foto</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-4 pt-4">
                        <button type="button" onclick="history.back()" class="flex-1 py-4 rounded-xl border border-gray-200 text-xs font-black text-gray-400 uppercase tracking-widest hover:bg-gray-50 transition-all">Batal</button>
                        <button type="submit" class="flex-2 w-full bg-[#1a365d] text-white py-4 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-900/20 hover:bg-[#0f213a] transition-all">Kirim Konfirmasi</button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <script>
        function displayPreview(input) {
            const container = document.getElementById('preview-container');
            const imgPreview = document.getElementById('img-preview');
            const placeholder = document.getElementById('placeholder-text');
            const fileNameText = document.getElementById('file-name-text');
            const dropzone = document.getElementById('dropzone');

            if (input.files && input.files[0]) {
                const reader = new FileReader();
                const file = input.files[0];

                reader.onload = function(e) {
                    imgPreview.src = e.target.result;
                    container.classList.remove('hidden');
                    placeholder.classList.add('opacity-0');
                    dropzone.classList.add('active'); // Ubah border jadi hijau
                    fileNameText.innerText = file.name; // Tampilkan nama file
                }

                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>