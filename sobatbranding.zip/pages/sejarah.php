<section class="py-24 px-6 bg-white">
    <div class="max-w-4xl mx-auto">
        <div class="flex justify-center mb-8">
            <span class="px-6 py-2 bg-blue-50 text-[#1a365d] text-[10px] font-black uppercase tracking-[4px] rounded-full border border-blue-100">Our Legacy</span>
        </div>

        <h1 class="text-5xl md:text-6xl font-black text-[#1a365d] italic tracking-tighter text-center mb-16 leading-tight">
            Membangun Jembatan <br> Kreatif untuk <span class="text-[#f38d2c]">UMKM.</span>
        </h1>

        <div class="relative mb-20">
            <div class="absolute -inset-4 bg-slate-50 rounded-[48px] -rotate-1"></div>
            <div class="relative bg-white border border-slate-100 p-10 md:p-16 rounded-[40px] shadow-xl shadow-blue-100/20">
                <div class="prose prose-slate max-w-none">
                    <p class="text-xl text-slate-500 font-bold leading-relaxed mb-8 italic">
                        "SobatBranding lahir dari sebuah keresahan sederhana: Mengapa brand lokal yang punya produk luar biasa sering kalah saing hanya karena visual yang kurang menarik?"
                    </p>
                    
                    <div class="space-y-6 text-slate-400 font-medium leading-loose text-sm">
                        <p>
                            Berdiri pada tahun 2024, kami memulai perjalanan sebagai komunitas kecil desainer yang ingin membantu pedagang kaki lima dan pemilik toko kelontong di sekitar kami. Kami percaya bahwa **desain kelas dunia tidak seharusnya hanya milik perusahaan besar.**
                        </p>
                        <p>
                            Melalui sistem **Escrow (Rekening Bersama)** yang kami kembangkan, kami ingin menciptakan rasa aman bagi pelaku UMKM untuk berinvestasi pada branding mereka tanpa takut tertipu. Setiap pixel yang kami buat adalah doa untuk kemajuan ekonomi Indonesia.
                        </p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 pt-12 border-t border-slate-50">
                    <div class="text-center">
                        <p class="text-3xl font-black text-[#1a365d] italic">2024</p>
                        <p class="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-2">Tahun Berdiri</p>
                    </div>
                    <div class="text-center">
                        <p class="text-3xl font-black text-[#f38d2c] italic">500+</p>
                        <p class="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-2">UMKM Terbantu</p>
                    </div>
                    <div class="text-center">
                        <p class="text-3xl font-black text-[#1a365d] italic">100%</p>
                        <p class="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-2">Karya Lokal</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center">
            <p class="text-xs font-bold text-slate-400 mb-6 uppercase tracking-[2px]">Ingin jadi bagian dari sejarah kami?</p>
            <a href="index.php?page=marketplace" class="inline-block bg-[#1a365d] text-white px-12 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-[#f38d2c] transition-all shadow-xl shadow-blue-100">Mulai Kolaborasi</a>
        </div>
    </div>
</section>