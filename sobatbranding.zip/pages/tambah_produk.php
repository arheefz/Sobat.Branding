<?php
// Proteksi: Hanya user yang sudah login yang bisa jualan
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Login dulu yuk biar bisa jualan!'); window.location='login.php';</script>";
    exit;
}
?>

<div class="bg-slate-50/30 min-h-screen py-16 px-6">
    <div class="max-w-3xl mx-auto">
        <div class="mb-12 text-center">
            <h1 class="text-4xl font-black text-[#1a365d] italic tracking-tighter uppercase">Buka <span class="text-[#f38d2c]">Layanan</span> Baru</h1>
            <p class="text-slate-400 font-bold text-xs uppercase tracking-[3px] mt-2">Isi detail jasa branding lo di bawah ini</p>
        </div>

        <div class="bg-white p-10 md:p-14 rounded-[48px] border border-slate-100 shadow-2xl shadow-blue-100/20">
            <form action="proses_tambah_produk.php" method="POST" enctype="multipart/form-data" class="space-y-8">
                
                <div>
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-3 ml-1">Judul Layanan / Jasa</label>
                    <input type="text" name="title" placeholder="Contoh: Desain Logo Minimalis" required 
                        class="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-[#1a365d] focus:bg-white rounded-[24px] outline-none transition-all font-bold text-[#1a365d]">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-3 ml-1">Harga (Rp)</label>
                        <input type="number" name="price" placeholder="500000" required 
                            class="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-[#1a365d] focus:bg-white rounded-[24px] outline-none transition-all font-bold text-[#1a365d]">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-3 ml-1">Kategori</label>
                        <select name="category" class="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-[#1a365d] focus:bg-white rounded-[24px] outline-none transition-all font-bold text-[#1a365d] appearance-none">
                            <option value="Desain">Desain Grafis</option>
                            <option value="Marketing">Social Media</option>
                            <option value="Website">Website</option>
                            <option value="Video">Video Editing</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black text-slate-400 uppercase tracking-[2px] mb-3 ml-1">Deskripsi Layanan</label>
                    <textarea name="description" rows="4" placeholder="Jelaskan apa saja yang didapat oleh pembeli..." required 
                        class="w-full p-6 bg-slate-50 border-2 border-transparent focus:border-[#1a365d] focus:bg-white rounded-[24px] outline-none transition-all font-bold text-[#1a365d]"></textarea>
                </div>

                <div>
                    <label class="block text-[10px] font-black text-orange-400 uppercase tracking-[2px] mb-3 ml-1">Foto Cover Produk (Grid)</label>
                    <input type="file" name="image" accept="image/*" required 
                        class="w-full p-5 bg-orange-50/50 border-2 border-dashed border-orange-100 rounded-[24px] font-bold text-xs text-[#f38d2c]">
                </div>

                <button type="submit" class="w-full bg-[#1a365d] text-white font-black py-6 rounded-[28px] shadow-2xl shadow-blue-200 hover:bg-[#f38d2c] transition-all uppercase tracking-[4px] text-xs active:scale-95">
                    Tayangkan Sekarang
                </button>
            </form>
        </div>
    </div>
</div>