<?php
// Ambil ID jasa biar asisten tau lagi bahas apa
$id_jasa = isset($_GET['id_jasa']) ? intval($_GET['id_jasa']) : 0;
$jasa_title = "Layanan Kami";

if ($id_jasa > 0) {
    $q = mysqli_query($conn, "SELECT title FROM services WHERE id = $id_jasa");
    if ($res = mysqli_fetch_assoc($q)) {
        $jasa_title = $res['title'];
    }
}
?>

<div class="max-w-2xl mx-auto px-6 py-10">
    <div class="bg-navy rounded-t-[40px] p-8 text-center text-white">
        <div class="w-20 h-20 bg-orange rounded-full flex items-center justify-center text-3xl mx-auto mb-4 shadow-xl border-4 border-white/20">
            🤖
        </div>
        <h2 class="text-xl font-black uppercase tracking-widest italic">SobatBot Asisten</h2>
        <p class="text-[10px] font-bold opacity-60 uppercase tracking-[2px]">Siap membantu UMKM naik kelas</p>
    </div>

    <div class="bg-white border-x border-slate-100 p-8 space-y-6">
        <div class="flex gap-4">
            <div class="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center text-xs">🤖</div>
            <div class="bg-slate-50 p-5 rounded-2xl rounded-tl-none border border-slate-100 max-w-[85%]">
                <p class="text-xs font-bold text-navy leading-relaxed">
                    Halo! Saya SobatBot. Kamu tertarik dengan jasa <span class="text-orange">"<?= htmlspecialchars($jasa_title) ?>"</span> ya? 
                    Apa yang ingin kamu lakukan sekarang?
                </p>
            </div>
        </div>

        <div class="grid gap-3 pt-4">
            <a href="https://wa.me/6285945626152?text=Halo%20Admin,%20saya%20mau%20tanya%20tentang%20<?= urlencode($jasa_title) ?>" 
               target="_blank"
               class="flex items-center justify-between p-5 bg-white border-2 border-slate-100 rounded-2xl hover:border-orange hover:bg-orange/5 transition-all group">
                <div class="text-left">
                    <p class="text-[11px] font-black text-navy uppercase tracking-widest mb-1 group-hover:text-orange">Tanya Langsung ke Penjual</p>
                    <p class="text-[9px] font-bold text-slate-400">Diskusi detail pengerjaan via WhatsApp</p>
                </div>
                <span class="text-xl">💬</span>
            </a>

            <a href="index.php?page=checkout&id=<?= $id_jasa ?>" 
               class="flex items-center justify-between p-5 bg-white border-2 border-slate-100 rounded-2xl hover:border-navy hover:bg-navy/5 transition-all group">
                <div class="text-left">
                    <p class="text-[11px] font-black text-navy uppercase tracking-widest mb-1">Langsung Order Saja</p>
                    <p class="text-[9px] font-bold text-slate-400">Bawa saya ke halaman pembayaran</p>
                </div>
                <span class="text-xl">🛒</span>
            </a>

            <button onclick="window.history.back()" 
               class="flex items-center justify-between p-5 bg-white border-2 border-slate-100 rounded-2xl hover:bg-slate-50 transition-all group">
                <div class="text-left">
                    <p class="text-[11px] font-black text-navy uppercase tracking-widest mb-1">Cari Jasa Lain</p>
                    <p class="text-[9px] font-bold text-slate-400">Kembali ke marketplace</p>
                </div>
                <span class="text-xl">⬅️</span>
            </button>
        </div>
    </div>

    <div class="bg-slate-50 rounded-b-[40px] p-6 text-center border border-t-0 border-slate-100">
        <p class="text-[9px] font-black text-slate-300 uppercase tracking-[3px]">SobatBranding Auto-Assistant</p>
    </div>
</div>