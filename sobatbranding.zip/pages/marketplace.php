<?php
// 1. Pengaturan Pagination (Halaman)
$perHalaman = 12; // Menampilkan 12 produk per halaman
$halamanAktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
$awalData = ($halamanAktif > 1) ? ($halamanAktif * $perHalaman) - $perHalaman : 0;

// 2. Filter Kategori
$category_filter = isset($_GET['category']) ? mysqli_real_escape_string($conn, $_GET['category']) : '';
$where = ($category_filter != '') ? "WHERE category = '$category_filter'" : "";

// 3. Hitung Total Data untuk navigasi halaman
$totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM services $where");
$totalData = mysqli_fetch_assoc($totalQuery)['total'];
$totalHalaman = ceil($totalData / $perHalaman);

// 4. Query Ambil Data (Gabungkan filter & pagination)
$sql = "SELECT * FROM services $where ORDER BY id DESC LIMIT $awalData, $perHalaman";
$q = mysqli_query($conn, $sql);
?>

<section class="relative pt-24 pb-32 px-6 bg-dot">
    <div class="max-w-5xl mx-auto text-center relative z-10">
        <div class="inline-flex items-center bg-white border border-slate-100 px-5 py-2.5 rounded-2xl mb-12 shadow-sm">
            <span class="animate-ping absolute h-2 w-2 rounded-full bg-[#f38d2c] opacity-75"></span>
            <span class="text-[10px] font-black text-[#f38d2c] uppercase tracking-[4px] ml-4">Escrow Managed Marketplace</span>
        </div>
        <h1 class="text-6xl md:text-8xl font-extrabold text-[#1a365d] mb-10 italic leading-[0.95] tracking-tighter">
            Partner Branding <br> <span class="relative inline-block text-[#f38d2c]">UMKM<svg class="absolute -bottom-2 left-0 w-full h-4" viewBox="0 0 300 20" fill="none" preserveAspectRatio="none"><path d="M5 15Q150 2 295 15" stroke="#f38d2c" stroke-width="12" stroke-linecap="round"/></svg></span> Indonesia
        </h1>
        <p class="text-slate-500 text-lg md:text-2xl max-w-3xl mx-auto font-medium leading-relaxed mb-16">Platform terpercaya untuk solusi desain grafis dan branding UMKM aman.</p>
        <div class="flex justify-center gap-6">
            <a href="#eksplor" class="bg-[#1a365d] text-white px-12 py-6 rounded-[24px] font-black text-xs uppercase tracking-[3px] shadow-2xl shadow-blue-200 hover:-translate-y-1 transition-all">Mulai Eksplor</a>
        </div>
    </div>
</section>

<section id="eksplor" class="max-w-7xl mx-auto px-6 py-24">
    <div class="flex flex-col md:flex-row items-end justify-between mb-20 gap-8">
        <div>
            <div class="h-1.5 w-10 bg-[#f38d2c] rounded-full mb-4"></div>
            <h2 class="text-4xl font-black italic uppercase tracking-tighter">
                <?= $category_filter ? "Kategori <span class='text-slate-200'>$category_filter</span>" : "Layanan <span class='text-slate-200'>Pilihan</span>" ?>
            </h2>
            <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-2">Menampilkan <?= $totalData ?> hasil karya kreator Indonesia</p>
        </div>

        <div class="flex gap-3 overflow-x-auto pb-2 no-scrollbar max-w-full md:max-w-2xl">
            <a href="index.php?page=marketplace#eksplor" class="px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all <?= ($category_filter == '') ? 'bg-[#1a365d] text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-100 hover:text-[#1a365d]' ?>">Semua</a>
            <?php 
            $categories = ['Desain Grafis', 'Digital Marketing', 'Website & IT', 'Video & Animasi'];
            foreach($categories as $cat): ?>
                <a href="index.php?page=marketplace&category=<?= urlencode($cat) ?>#eksplor" class="px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all <?= ($category_filter == $cat) ? 'bg-[#1a365d] text-white shadow-lg' : 'bg-white text-slate-400 border border-slate-100 hover:border-[#1a365d] hover:text-[#1a365d]' ?>">
                    <?= $cat ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-12">
        <?php while($row = mysqli_fetch_assoc($q)): ?>
        <div class="group bg-white rounded-[48px] border border-slate-100 hover:shadow-2xl transition-all overflow-hidden flex flex-col hover:-translate-y-4 duration-500">
            <div class="h-60 relative overflow-hidden">
                <img src="<?= $row['image'] ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                <div class="absolute bottom-4 left-4 bg-white/90 backdrop-blur px-4 py-2 rounded-xl shadow-sm">
                    <p class="text-[9px] font-black text-[#1a365d] uppercase tracking-widest">Store: <?= $row['brand_name'] ?? 'Sobat Partner' ?></p>
                </div>
            </div>
            <div class="p-10 flex flex-col flex-grow">
                <h3 class="text-xl font-bold mb-10 h-14 italic leading-tight text-[#1a365d]"><?= $row['title'] ?></h3>
                <div class="mt-auto pt-8 border-t flex items-center justify-between">
                    <div>
                        <p class="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">Mulai Dari</p>
                        <p class="text-2xl font-black tracking-tighter text-[#1a365d]">Rp<?= number_format($row['price']/1000, 0) ?>k</p>
                    </div>
                    <a href="index.php?page=detail&id=<?= $row['id'] ?>" class="bg-[#1a365d] text-white p-5 rounded-[22px] group-hover:bg-[#f38d2c] transition-all shadow-lg">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                    </a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <div class="mt-24 flex justify-center items-center gap-3">
        <?php if($halamanAktif > 1): ?>
            <a href="index.php?page=marketplace&halaman=<?= $halamanAktif - 1 ?>&category=<?= urlencode($category_filter) ?>#eksplor" class="w-14 h-14 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-[#1a365d] hover:bg-[#1a365d] hover:text-white transition-all shadow-sm">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"/></svg>
            </a>
        <?php endif; ?>

        <?php for($i = 1; $i <= $totalHalaman; $i++): ?>
            <?php if($i >= $halamanAktif - 2 && $i <= $halamanAktif + 2): ?>
                <a href="index.php?page=marketplace&halaman=<?= $i ?>&category=<?= urlencode($category_filter) ?>#eksplor" 
                   class="w-14 h-14 flex items-center justify-center rounded-2xl font-black text-xs transition-all <?= ($i == $halamanAktif) ? 'bg-[#f38d2c] text-white shadow-xl shadow-orange-200' : 'bg-white border border-slate-100 text-slate-400 hover:border-[#1a365d] hover:text-[#1a365d]' ?>">
                    <?= $i ?>
                </a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if($halamanAktif < $totalHalaman): ?>
            <a href="index.php?page=marketplace&halaman=<?= $halamanAktif + 1 ?>&category=<?= urlencode($category_filter) ?>#eksplor" class="w-14 h-14 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-[#1a365d] hover:bg-[#1a365d] hover:text-white transition-all shadow-sm">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"/></svg>
            </a>
        <?php endif; ?>
    </div>
</section>