<?php
// Cek jika form disubmit
if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = intval($_POST['price']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $brand_name = mysqli_real_escape_string($conn, $_POST['brand_name']);

    // LOGIKA UPLOAD GAMBAR
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    // Cek apakah ada gambar yang diupload
    if ($error === 4) {
        echo "<script>alert('Pilih gambar terlebih dahulu!');</script>";
    } else {
        // Validasi ekstensi gambar
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png', 'webp'];
        $ekstensiGambar = explode('.', $namaFile);
        $ekstensiGambar = strtolower(end($ekstensiGambar));

        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            echo "<script>alert('Bukan file gambar yang valid (Gunakan jpg/jpeg/png/webp)');</script>";
        } elseif ($ukuranFile > 2000000) { // Max 2MB
            echo "<script>alert('Ukuran gambar terlalu besar! (Maksimal 2MB)');</script>";
        } else {
            // Generate nama file baru agar tidak bentrok
            $namaFileBaru = uniqid() . '.' . $ekstensiGambar;
            $tujuanPenyimpanan = 'uploads/services/' . $namaFileBaru;

            if (move_uploaded_file($tmpName, $tujuanPenyimpanan)) {
                // Jika file berhasil pindah, simpan path-nya ke database
                $query = "INSERT INTO services (title, category, price, description, brand_name, image, rating) 
                          VALUES ('$title', '$category', '$price', '$description', '$brand_name', '$tujuanPenyimpanan', '5.0')";
                
                if (mysqli_query($conn, $query)) {
                    echo "<script>alert('Jasa berhasil diupload!'); window.location='index.php?page=marketplace';</script>";
                } else {
                    echo "<script>alert('Gagal simpan ke database');</script>";
                }
            } else {
                echo "<script>alert('Gagal mengupload file ke folder server');</script>";
            }
        }
    }
}
?>

<div class="max-w-3xl mx-auto px-6 py-20">
    <div class="bg-white rounded-[48px] border border-slate-100 shadow-2xl overflow-hidden">
        <div class="bg-navy p-12 text-center text-white">
            <h2 class="text-3xl font-black italic uppercase tracking-tighter text-white">Buka Toko <span class="text-orange">Kreatif</span></h2>
            <p class="text-[10px] font-bold opacity-60 uppercase tracking-[3px] mt-2">Upload file portofolio terbaik Anda</p>
        </div>

        <form action="" method="POST" enctype="multipart/form-data" class="p-12 space-y-8">
            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Nama Brand/Toko</label>
                <input type="text" name="brand_name" required placeholder="Contoh: Pixel Studio" 
                    class="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-orange font-bold text-navy transition-all">
            </div>

            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Judul Layanan</label>
                <input type="text" name="title" required placeholder="Contoh: Desain Logo Minimalis" 
                    class="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-orange font-bold text-navy transition-all">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Kategori</label>
                    <select name="category" class="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-orange font-bold text-navy">
                        <option value="Desain Grafis">Desain Grafis</option>
                        <option value="Digital Marketing">Digital Marketing</option>
                        <option value="Website & IT">Website & IT</option>
                        <option value="Video & Animasi">Video & Animasi</option>
                    </select>
                </div>
                <div>
                    <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Harga (Rp)</label>
                    <input type="number" name="price" required placeholder="Contoh: 150000" 
                        class="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-orange font-bold text-navy transition-all">
                </div>
            </div>

            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Deskripsi Layanan</label>
                <textarea name="description" rows="4" required placeholder="Jelaskan detail layanan Anda..." 
                    class="w-full px-6 py-5 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:border-orange font-bold text-navy transition-all"></textarea>
            </div>

            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 block">Upload Gambar Portofolio</label>
                <div class="relative group">
                    <input type="file" name="gambar" id="gambar" required 
                        class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10">
                    <div class="w-full px-6 py-10 bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center group-hover:border-orange transition-all">
                        <span class="text-3xl mb-2">📸</span>
                        <p id="file-name" class="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Klik atau tarik file ke sini</p>
                        <p class="text-[9px] text-gray-300 mt-1 italic">Maksimal 2MB (JPG, PNG, WEBP)</p>
                    </div>
                </div>
            </div>

            <button type="submit" name="submit" class="w-full bg-navy text-white py-6 rounded-2xl font-black uppercase tracking-[3px] text-xs hover:bg-orange transition-all shadow-xl shadow-blue-100">
                Tayangkan Jasa Sekarang
            </button>
        </form>
    </div>
</div>

<script>
// Script kecil untuk menampilkan nama file setelah dipilih
document.getElementById('gambar').onchange = function () {
    const fileName = this.files[0].name;
    document.getElementById('file-name').innerHTML = "File terpilih: " + fileName;
    document.getElementById('file-name').classList.add('text-orange');
};
</script>