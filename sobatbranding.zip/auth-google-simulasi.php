<a href="auth-google-simulasi.php" class="w-full py-3 border border-gray-100 rounded-xl flex items-center justify-center gap-2 text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all">
    <img src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" class="w-4">
    Lanjut dengan Google
</a>